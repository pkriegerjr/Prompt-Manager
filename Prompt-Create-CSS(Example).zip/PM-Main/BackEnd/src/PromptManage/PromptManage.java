
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.nio.charset.StandardCharsets;

public class PromptManage {
    // Simulação de banco de dados em memória
     static List<String> prompts = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        // Cria um servidor HTTP na porta 8082
        HttpServer server = HttpServer.create(new InetSocketAddress(8082), 0);
        
        // Cria o endpoint /api/prompts
        server.createContext("/api/prompts", new PromptHandler());
        
        server.setExecutor(null); 
        System.out.println("Servidor iniciado em http://localhost:8082");
        server.start();
    }

    static class PromptHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Configuração de CORS para permitir que o HTML local acesse o Java
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                exchange.close();
                return;
            }

            String method = exchange.getRequestMethod();
            String response = "";
            int statusCode = 200;

            try {
                if ("POST".equalsIgnoreCase(method)) {
                    InputStream is = exchange.getRequestBody();
                    String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                
                    String prompt = extrairValor(body, "prompt");

                    validarPrompt(prompt);

                    prompts.add(prompt);
                    response = "Prompt cadastrado com sucesso!";
                    statusCode = 200;

                } else if ("GET".equalsIgnoreCase(method)) {
                    response = "Prompts cadastrados: " + prompts.toString();
                    statusCode = 200;
                } else {
                    response = "Método não permitido";
                    statusCode = 405;
                }
            } catch (PromptException e) {
                response = "Erro: " + e.getMessage();
                statusCode = 400;
            } catch (Exception e) {
                response = "Erro interno no servidor";
                statusCode = 500;
            }

            byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(statusCode, responseBytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(responseBytes);
            }
        }

        private String extrairValor(String json, String campo) {
            try {
                int index = json.indexOf("\"" + campo + "\"") + campo.length() + 3;
                int fim = json.indexOf("\"", index + 1);
                return json.substring(index + 1, fim);
            } catch (Exception e) { return ""; }
        }
    }

    // Método para validar os prompts cadastrados
    public static void validarPrompt(String prompt) throws PromptException {
        if (prompt == null || prompt.trim().isEmpty()) {
            throw new PromptException("O prompt não pode estar vazio.");
        }
        if (prompt.length() < 10) {
            throw new PromptException("O prompt deve ter pelo menos 10 caracteres.");
        }
    }
}